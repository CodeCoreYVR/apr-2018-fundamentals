// chat app

// 1. form
// 2. log, conversation
// 2a. name: sentence
// 3. UX - clear the text field after the user submitted their sentence
// 3a. give the text field focus so we can just start typing
// 4. admin: delete or remove
