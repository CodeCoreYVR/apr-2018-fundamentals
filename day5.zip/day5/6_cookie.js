// make a cookie class
class Cookie {
  constructor() {
    console.log("A cookie was created!");
    this.sugar = 10;
    this.flour = 20;
    this.glutten = false;
  }
}
// make 3 instances of cookies: oatmeal, chocolateChip, shortBread
const oatmeal = new Cookie();
const chocolateChip = new Cookie();
const shortBread = new Cookie();
// create a constructor method that console.log "a cookie was created"

// give each cookie three properties: sugar, flour, glutten
