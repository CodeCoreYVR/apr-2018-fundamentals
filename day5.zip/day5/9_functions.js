// declaritive function
// anonymous function
// expressive function

// methods, a function with an object

// class, idea, this describes an object, but it is not a physical object

// functions - are considered first class citizens
// that means that they have permission to go anywhere they want!

// javascript is a functional programming language

// asynchronous - means that you can run code out of sequence
setTimeout(function(){ console.log("A") }, 1000);
setTimeout(function(){ console.log("B") }, 2000);
setTimeout(function(){ console.log("C") }, 3000);

console.log("B");
console.log("C");
console.log("A");

// dinner
console.log("mussels");
console.log("steak");
console.log("salad");
console.log("creme brule");

setTimeout(function() { console.log("dessert") }, 10000);
setTimeout(function() { console.log("salad") }, 3000);
setTimeout(function() { console.log("steak") }, 8000);
setTimeout(function(){ console.log("mussels") }, 1000);










//
