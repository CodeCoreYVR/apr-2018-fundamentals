// classes
// classification
// bring order to chaos
// sapien - harari

// music - rock, country, jazz
// we classify things, to solve a problem
// create me a retail system
// create me a financial application
// make me a run forever game

// class
// blueprints
// cookie cutters
// pepper grinders

// class describes an object might be
// class is an idea

// constructing them to create them


// e.g. array
// the array is a list of information
// Array is the class
// shoppingList is an object
// shoppingList is an instance of the array class
let shoppingList = new Array();
let shoppingList = [];

// how do we make classes
class House {
  // when a house is built, the first thing that is called is the constructor method
  constructor() {
    console.log("a new house is built");
    this.colour = 'grey';
  }
} // blueprints for the house

// hire a general contractor
// buy materials
// get permits
// construct the house
const bungalow = new House();
// bungalow.colour = "grey";
const townhouse = new House();
// townhouse.colour = "grey";
const mansion = new House();
// mansion.colour = "grey";
// home.colour = "grey";


// class Array {}
// let shoppingList = new Array();






//





//
